using Microsoft.AspNetCore.Cors.Infrastructure;
using Newtonsoft.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        b => b.AllowAnyHeader()
        .AllowAnyOrigin()
        .AllowAnyMethod());
});

var app = builder.Build();


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseCors("AllowAll");
//app.UseCors(policy => policy.AllowAnyHeader()
//                            .AllowAnyMethod()
//                             .SetIsOriginAllowed(origin => true)
//                             .AllowCredentials());

app.UseMiddleware<CorsMiddleware>();
app.UseStaticFiles();



app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Run();


