﻿    
    $(document).ready(function(){
        alert("hello")
        $.ajax({
            type: "GET",
            url:"http://localhost:5070/api/Candidate/GetAllCandidates",
            datatype: "Jsonp",
            success: function (result) {
                //var obj = JSON.parse(JSON.stringify(result))
                //alert(obj);
                alert(JSON.stringify(result));
            },
            error: function (req, status, error) {
                console.log(status)
            }

        });
    });

function populateCandidates(select, data) {
    select.html('');
    var items = [];
    $.each(data, function (id, option)
    {
        items.push('<li class="list-group-item text-center"><h5>' + option.msg +
            '</h5></li>');
    }); select.append(items.join(''));
}
    

